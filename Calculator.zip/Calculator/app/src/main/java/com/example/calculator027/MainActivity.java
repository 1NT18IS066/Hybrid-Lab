package com.example.Calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText num1, num2;
        Button add;
        TextView res;

        // Fetching Values
        num1 = findViewById(R.id.editTextTextPersonName);
        num2 = findViewById(R.id.editTextTextPersonName2);
        add = findViewById(R.id.button);
        res = findViewById(R.id.textView4);

        add.setOnClickListener(view -> {
            int n1 = Integer.parseInt(num1.getText().toString());
            int n2 = Integer.parseInt(num2.getText().toString());

            int sum = n1 + n2;

            // To display result
            res.setText(" " + sum);

            String TAG = "MainActivity.java";
            Toast.makeText(getApplicationContext(), "Addition Successful", Toast.LENGTH_LONG).show(); // To display message to the user
            Log.d(TAG, "Sum is " + sum);  // (in logcat) for the developer to debug
        });
    }
}